#!/usr/bin/env python3.5
#-*- coding: utf-8 -*-

import cryptocompare

# J'ai mis une boucle while car si on veut pas quitter >
# il reprendra directement au debut

while  True:


#Listes

	crypto = cryptocompare.get_coin_list(format=True)
	for Listes in crypto:
		print(Listes)

# Les prix

	Accounte = input('Choisissez votre monnaie :')
	Account = cryptocompare.get_price(Accounte, curr='USD',full=False)
	print(Account)

#La journee

	Journee = cryptocompare.get_historical_price_day(Accounte, curr='EUR')
	input('Choisissez votre journee :')
	print(Journee)

#Hour

	Heure = cryptocompare.get_historical_price_hour(Accounte, curr='EUR')
	input('Choisissez votre heure :')
	print(Heure)

#Sortir

	q = input('Tapez q pour sortir:')
	if q == 'q':
		exit()
	else:
		print("Vous n'avez pas saisis la bonne touche")


